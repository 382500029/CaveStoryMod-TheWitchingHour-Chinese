===== THE WITCHING HOUR =====
By Carrot Lord
Original game: Cave Story (Doukutsu Monogatari) by Studio Pixel

"There was once a time when fairies, giants, titans, and
fantastical creatures of all sorts ruled the land.
Then, came the humans, with no remarkable features at all.
Their willingness to move forward in both technology and
society seemed to be their best hope, though.
And thus, civilization was born from the ashes of
savagery. 
The kingdom of fairies, the kingdom of giants, and the
kingdom of all other magical beings had fallen to
corruption far more than once.
It was not as if the human kingdom would not succumb to the
same fate.
But though the great wars had past and eaten away at the human
realm as well, the King of Glass was one exception to such horrors.
This one king looked like a frail boy whose body was so fragile,
it could break like glass.
Though weak and unimposing, the King of Glass was the most
benevolent of all kings, using his sharp mind to bring to his
people a century of prosperity. It was under him that humans
thrived.
After the king came the first reigning female, Queen Faustina
the Elder. All was well. All was peaceful.
Suddenly, Faustina the Elder's daughter was kidnapped by an
assassin of sorts. Such news was a great shock to the kingdom.
And it had been said that a great prophet would be born in the
kingdom. That prophet never appeared.
And so, with the anger imposed by the people of the human's kingdom,
they began to blame other realms, as humans do often.
Faustina the Younger emerged from darkness and became the
queen of the fairies, such that the humans calmed as they saw their 
young human queen as a leader of a foreign race.
However, the humans soon saw the power of rage and corruption. Faustina
the Younger was not the young girl filled with the hopes
and dreams of all the human kingdom, as they all remembered.
Instead, by taking the great crown of the fairies, she became
power hungry.
Faustina the Younger's cruelty spread all across the land.
She would execute humans and all who opposed her. No one was safe
from her terror. She had no excuse either: the fairy empire had
achieved a level of near-perfection, near-utopia. 
One day, the queen disappeared. Human villages received a moment
of relief.
Thus is the start of the Witching Hour."

===== HOW TO PLAY =====
As if you didn't know this stuff already:

Default Controls:
Arrow keys = move
Down key = action button. Talk to NPCs, open doors, etc.
Z = jump (or accept in menus)
X = attack (or exit inventory)
A,S = switch weapons
W = special

===== MUSICAL CREDITS =====
World 1
7th Saga
Produce & Enix

Albinoni Adagio in G Minor
Giazotto

Arcana Rooks
Arcana
HAL Laboratory

Ayla's Theme
Chrono Trigger
Square (Enix)

Battle 2
Chrono Trigger
Square (Enix)

Eternal Recurrence
Secret of Mana
Square (Enix)

What the Forest Taught Me
Secret of Mana
Square (Enix)

Goron City Theme
Zelda: Ocarina of Time
Nintendo

Curse of the Iron Pipe
La Mulana
NIGORO - Naramura, duplex, and Samieru

Northwall
Actraiser
Square Enix

Cosmic Illusion
Matthew J. Drollinger

Moonsong Empire
Original "Moonsong" track by Studio Pixel

===== THANKS & CREDITS =====
Here�s a list of people to whom this mod owes some credit.
Daisuke Amaya � Yes, this is Studio Pixel himself. The great man. The daring game maker. The innovator. Many other things too. Anyway, he�s gotten to the point where people practically worship him, so yeah, he�s really that important.
Wistil � He created the program CaveEditor, a Cave Story modification tool that I could not do without.
Noxid � Put together the Assembly Compendium and added more stuff to the ASM functions list. Very useful stuff. Also a great mod maker. He�s transformed his own mod into a C++ based fangame by now.
GIRakaCheezer � Excellent mod maker and cool guy overall. Very talented in many areas. WTF Story can be a good inspiration for any modder.
Sean McLaughlin � He�s the man who made a z80 assembly tutorial for graphing calculators. I would be a lot further behind with assembly hacking without him.
Xaser � Great inspiration since he created the mod Schism. He also did the English translation (well, translation by clicking buttons and figuring out what probable purpose they had) for OrgMaker version 2.
Lace � Good assembly hacker. He�s posted some useful ASM information on various topics.
Runelancer � The original pioneer of assembly hacking. His crazy hacks can be seen in the mod Original Sin. His threads contain some great knowledge.
sshsigi � Created SeaTone, the thing that lets you easily make custom sounds in Cave Story. It�s a nice program to have.
Trickybilly � Someone who has always been willing to give me feedback on my mods.
DoubleThink � Appreciated by many modders; this guy gives tons of feedback on CS mods of all sorts.
Madotsuki � For playing the starring role in Yume Nikki, for giving me a page of good feedback, and giving me the final motivation to actually make a development blog.
Important: If you think I forgot you and you managed to contribute to this mod project in some way, then please contact me through the Cave Story Tribute Site forums using visitor message or private message. Don�t be afraid to ask � if you really deserve the thanks, you should get it after all.
Opt out of Publicity: If you have been credited and do not want to be on this list, contact me in the same way and I�ll remove you as soon as I can.

===== VERSION HISTORY =====

VERSION 1.21
-Fixed a spelling error.

VERSION 1.2
-Finished up Technology Area, along with custom boss.
-Floating cities area finished.

VERSION 1.1
-Major revamp: Options menu
-Completely remade Goron's Theme ORG
-Changed some graphics
-New custom boss
-Finished off Sand Caverns
-Underwater Zone
-Crossbow bolts don't auto-accelerate anymore
-Portal puzzle is easier (guy with blue hat will
give you hints in Easy Mode)
-New background for first area.
-New weapon
-Added a few custom sounds
-Applied the new WAV/drum hack thanks to Noxid & DB
-New ORGs

VERSION 1.0
-Witching Hour released to public.